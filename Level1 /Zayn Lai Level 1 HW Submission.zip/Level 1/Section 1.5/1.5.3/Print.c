//
//  Print.c
//  1.5.3
//
//  Created by Ziyan Lai on 5/27/20.
//  Copyright © 2020 Ziyan Lai. All rights reserved.
//  Definition of the function 

#include <stdio.h>

// implementation of the function that calculate and print the result 
void multiplyByTwo(double input)
{
     printf("%.1lf multiplied by 2 is %.1lf.\n",input, input*2);
}

