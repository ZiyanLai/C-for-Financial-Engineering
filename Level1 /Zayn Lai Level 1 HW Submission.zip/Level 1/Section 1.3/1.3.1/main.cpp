//
//  main.cpp
//  1.3.1
//
//  Created by Ziyan Lai on 5/26/20.
//  Copyright © 2020 Ziyan Lai. All rights reserved.
//  Print out the message

#include <stdio.h>

int main()
{
    // print the line on screen
    printf("My first C-program\nis a fact!\nGood, isn't it?\n");
}
